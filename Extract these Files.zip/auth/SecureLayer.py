from cryptography.fernet import Fernet
import keyring
import bcrypt
import json
from pathlib import Path
from auth.logging import Logger



class SecureLayer:
    def __init__(self):
        self.logger = Logger()
        """
        Initializes the SecureLayer class by setting up the encryption and
        keyring for secure storage and retrieval of the encryption key.
        """
        try:
            self.setup_cipher()
            self.data_file = Path('auth/app.enc')  # File path for encrypted data storage
        except Exception as e:
            self.logger.error(f"Error initializing SecureLayer class: {e}")
        
    def setup_cipher(self):
        """
        Initializes the cipher key using keyring. If no key is found, a new key is generated
        and stored securely using keyring.
        """
        try:
            self.key = keyring.get_password("app_name", "fernet_key")
            if self.key is None:
                self.key = Fernet.generate_key()
                keyring.set_password("app_name", "fernet_key", self.key.decode())
            else:
                self.key = self.key.encode()
            self.cipher = Fernet(self.key)
        except Exception as e:
            self.logger.error(f"Error setting up encryption keys: {e}")
            raise

    def chk_if_exits(self) -> bool:
        """Checks if the encrypted data file exists."""
        return Path(self.data_file).exists()

    def save_data(self, data: bytes) -> bool:
        """Saves encrypted data to a file."""
        try:
            with open(self.data_file, 'wb') as file:
                file.write(data)
                return True
        except Exception as e:
            self.logger.error(f"Error saving encrypted data: {e}")
            return False

    def encrypt(self, username: str, email: str, password: str) -> bool:
        """Encrypts user data and saves it to the file."""
        try:
            password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())  # Hash the password
            user = [username, email, password.decode()]
            user_bytes = json.dumps(user).encode()
            encrypted_data = self.cipher.encrypt(user_bytes)
            return self.save_data(encrypted_data)
        except Exception as e:
            self.logger.error(f"Error during encryption: {e}")
            return False

    def load_data(self) -> bytes:
        """Loads encrypted data from the file."""
        if not self.chk_if_exits():
            self.logger.error("Encrypted data file not found.")
            return None
        try:
            with open(self.data_file, 'rb') as file:
                return file.read()
        except Exception as e:
            self.logger.error(f"Error loading encrypted data: {e}")
            return None

    def decrypt(self) -> list[str]:
        """Decrypts the encrypted user data."""
        encrypted_data = self.load_data()
        if encrypted_data is None:
            return []
        try:
            decrypted_data = self.cipher.decrypt(encrypted_data)
            user_data = json.loads(decrypted_data.decode())
            return user_data
        except Exception as e:
            self.logger.error(f"Error during decryption: {e}")
            return []

    def check_password(self, password: str) -> bool:
        """Validates the password by comparing it to the stored hashed password."""
        try:
            user = self.decrypt()
            if user:
                matched = bcrypt.checkpw(password.encode(), user[2].encode())  # Compare hashed password
                return matched
            return False
        except Exception as e:
            self.logger.error(f"Error checking password: {e}")
            return False

    def validate(self, username: str, password: str) -> bool:
        """Validates the username and password against the decrypted data."""
        try:
            user = self.decrypt()
            if user and username == user[0] and self.check_password(password):
                return True
            return False
        except Exception as e:
            self.logger.error(f"Error during validation: {e}")
            return False

# Example Usage:
# secure_layer = SecureLayer()
# secure_layer.encrypt("user1", "user1@example.com", "password123")
# is_valid = secure_layer.validate("user1", "password123")
# print("User Validated:", is_valid)
