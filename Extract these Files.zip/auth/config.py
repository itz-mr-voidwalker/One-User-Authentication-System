# config.py
from dotenv import load_dotenv
import os
from pathlib import Path

# Ensure .env file from root is loaded
env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

def load_env(ENV_Variable: str) -> str | None:
    """
    Loads and returns the value of the specified environment variable.

    Args:
        ENV_Variable (str): The name of the environment variable to retrieve.

    Returns:
        str | None: Returns the value of the environment variable if it exists,
                    otherwise returns None.
    """
    try:
        value = os.getenv(ENV_Variable)
        if value is None:
            print(f"⚠️ Warning: Environment variable '{ENV_Variable}' is not set. Please check your .env file.")
        return value
    except Exception as e:
        print(f"❌ Error occurred while loading the environment variable '{ENV_Variable}': {e}")
        return None

def set_session() -> bool:
    """
    Sets Session After Login.

    Returns:
        bool: True if session was set successfully, False otherwise.
    """
    try:
        os.environ["SESSION"] = "true"
        return True
    except Exception as e:
        print(f"❌ Error occurred while setting session: {e}")
        return False
    
    

def destroy_session() -> bool:
    """
    Destroys the session.

    Returns:
        bool: True if session was destroyed successfully, False otherwise.
    """
    try:
        if "SESSION" in os.environ:
            del os.environ["SESSION"]
        return True
    except Exception as e:
        print(f"❌ Error occurred while destroying session: {e}")
        return False
    

def is_session_active() -> bool:
    """
    Checks if session is active.

    Returns:
        bool: True if session is active, False otherwise.
    """
    return os.environ.get("SESSION") == "true"