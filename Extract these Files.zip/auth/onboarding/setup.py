from auth.SecureLayer import SecureLayer
from auth.SendEmail import EmailVerification
from auth.logging import Logger
import random
import time
import getpass
import re

class Setup:
    """
    Setup class for configuring user details with email verification
    and data encryption.
    """

    def __init__(self):
        """
        Initializes the Setup class by creating a SecureLayer instance
        and initiating the setup process.
        """
        self.logger = Logger()
        self.logger.info("Entered Onboarding Setup")
        print("🛠️ Welcome to the Configuration Setup 🛠️")
        print("⚠️ Please follow the instructions to set up your account securely.")
        self.enc = SecureLayer()
        self.setup()

    def setup(self):
        """
        Handles the main configuration setup process, including user input
        for username, email, and password, email verification, and data 
        encryption. If everything is valid, it proceeds to the login.

        Implements error handling and prompts the user to retry in case of
        invalid data or failure.
        """
        try:
            while True:
                # Get user input for username, email, and password
                username = input("👤 Enter the Username: ").strip()
                email = input("📧 Enter your email: ").strip()
                password = getpass.getpass("🔑 Enter your Password: ").strip()

                # Validate the email format
                if not self._is_valid_email(email):
                    self.logger.error("Invalid Email Format")
                    print("❌ Invalid Email format. Please enter a valid email address.")
                    continue  # Prompt the user to retry

                # Validate password length
                if len(password) < 8:
                    self.logger.error("Invalid Password length")
                    print("❌ Password should be at least 8 characters long. Please try again.")
                    continue  # Prompt the user to retry

                # Verify email before proceeding
                try:
                    _email_verified = self.verify_email(email)
                    if _email_verified:
                        self.logger.info("Email Verification Success")
                        print("✅ Email Verification Completed!")

                        # Encrypt the user data and proceed with login
                        if self.enc.encrypt(username, email, password):
                            self.logger.info("Setup Completed")
                            from auth.login import Login
                            login = Login()
                            break  # Exit the loop and proceed to login
                        else:
                            self.logger.error("Encryption Failed")
                            print("❌ Failed to encrypt data. Please try again.")
                            print("-" * 50)
                            continue  # Retry the setup process
                    else:
                        self.logger.error("Email Verification failed")
                        print("❌ Email Verification Failed. Please try again.")
                        print("-" * 50)
                        continue  # Retry the email verification step
                except Exception as e:
                    self.logger.error("Error Occured during email verification")
                    print("❌ Error occurred during email verification:", e)
                    print("Please try again later.")
                    return  # Exit if error occurs during verification

        except Exception as e:
            self.logger.error("Error Occured During Setup")
            print("❌ Error Occurred during setup:", e)
            print("Please try again later.")
            return  # Exit if setup fails

    def verify_email(self, email: str) -> bool:
        """
        Sends a verification code to the provided email and prompts
        the user to input the received code for verification.

        Args:
            email (str): The email address to send the verification code to.

        Returns:
            bool: Returns True if the email is verified successfully, otherwise False.
        """
        try:
            self.code = random.randint(10000, 99999)  # Generate a 5-digit code
            created_at = int(time.time())  # Store timestamp of code generation

            # Send the verification email
            email_mgr = EmailVerification()
            email_mgr.send_email(
                subject='Email Verification',
                code=self.code,
                to_email=email
            )

            try:
                # Get the verification code from the user
                user_inp = int(input("🔢 Enter the code sent to your email: "))
                current_time = int(time.time())

                # Check if the code has expired (10-minute window)
                if current_time - created_at > 600:
                    print("⏳ Code expired! Please request a new one.")
                    return False  # Expired code

                # Verify if the entered code matches the generated code
                if user_inp == self.code:
                    print("✅ Email verified successfully!")
                    return True  # Successful verification
                else:
                    print("❌ Incorrect code. Please try again.")
                    return False  # Incorrect code

            except ValueError:
                print("❗ Invalid input! Please enter digits only.")
                return False  # Invalid input from user

        except Exception as e:
            print("❌ Error occurred during email verification:", e)
            print("Please try again later.")
            return False  # Return False if error occurs

    def _is_valid_email(self, email: str) -> bool:
        """
        Validates the provided email address format using a regular expression.

        Args:
            email (str): The email address to validate.

        Returns:
            bool: Returns True if the email format is valid, otherwise False.
        """
        try:
            # Validate the email format using the pattern matcher
            if self._pattern_matcher(email):
                return True
            else:
                print("❌ Invalid email format. Please ensure your email looks like: user@example.com")
                return False
        except Exception as e:
            print("❌ Error occurred during email validation:", e)
            return False

    def _pattern_matcher(self, email: str) -> bool:
        """
        Matches the email address against a regular expression pattern to
        ensure it follows a valid format.

        Args:
            email (str): The email address to check against the pattern.

        Returns:
            bool: Returns True if the email matches the pattern, otherwise False.
        """
        try:
            self.email_pattern = r"""
                ^(?!.*\.\.)                             # No double dots
                [a-zA-Z0-9](?:[a-zA-Z0-9._+-]{0,62}[a-zA-Z0-9])?    # Local part
                @
                [a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?       # Domain
                (?:\.[a-zA-Z]{2,10})+$                   # TLD and sub-TLDs
            """
            # Return True if the email matches the regex pattern
            return True if re.match(self.email_pattern, email, re.VERBOSE) else False
        except Exception as e:
            print("❌ Error occurred while matching the email pattern:", e)
            return False
