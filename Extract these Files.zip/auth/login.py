from auth.SecureLayer import SecureLayer
from auth.config import set_session, destroy_session
from app.main import app
import getpass
from auth.forgot_pass import ForgotPassword
from auth.logging import Logger

class Login:
    """
    Login class to handle user authentication, allowing users to log in
    securely or recover their password if necessary. This class provides
    helpful guidance and error handling to ensure a smooth user experience.
    """
    
    def __init__(self):
        destroy_session()
        """
        Initializes the Login class, setting up necessary components and
        initiating the login process with clear user instructions.
        """
        self.logger = Logger()
        print("=" * 50)
        self.enc = SecureLayer()
        print("🔐 Welcome to the Secure Login System 🔐")
        print("⚠️ Please enter your username and password to log in.")
        print("❓ If you've forgotten your credentials, type 'forgot' at any time for assistance.")
        print("=" * 50)
        self.logger.info("Entered Login Page")
        self.initiate_login()

    def initiate_login(self):
        """
        Prompts the user for their username and password, validates the input,
        and attempts to log the user in. If invalid credentials are provided,
        the user is given a chance to retry or initiate the password recovery process.

        The method also includes a fallback mechanism to handle errors or invalid input
        and provides helpful instructions at every stage.
        """
        try:
            while True:
                # Get user input for username and password
                username = input("👤 Enter your username:").strip()
                password = getpass.getpass("🔑 Enter your password:").strip()

                # Check if the user wants to recover their password
                if "forgot" in username or "forgot" in password:
                    print("💡 You can recover your password by following the instructions.")
                    forgot_pass = ForgotPassword()                
                    break

                # Check if both username and password are entered
                if username and password:
                    try:
                        # Validate the credentials
                        is_valid = self.enc.validate(username, password)
                        if is_valid:
                            if set_session():
                                self.logger.info("Login Successful")
                                print("✅ Login Successful. Welcome! 🎉")
                                set_session()
                                print("🔑 You can now access your secure account.")
                                print("=" * 50)
                                app()  # Proceed with the main application
                                break
                            else:
                                print("Session Creation Failed")
                        else:
                            self.logger.error("Invalid Credentials")
                            print("\n❌ Invalid credentials. Please check your username and password.")
                            print("🔑 Ensure there are no extra spaces or typos.")
                            print("📝 You may also type 'forgot' in either field if you need assistance with password recovery. 🤔")
                            print("=" * 50)
                    except Exception as e:
                        self.logger.error("Invalid Credentials")
                        print("❌ Error occurred during validation:", e)
                        print("🔄 Please try again later. If the issue persists, contact support.")
                        return
                else:
                    # Fallback for missing input
                    self.logger.error("Empty Inputs")
                    print("⚠️ Both fields are required to proceed. Please enter your username and password.")
                    print("🔑 Ensure there are no leading or trailing spaces.")
                    print("=" * 50)
        except Exception as e:
            # General fallback for any unexpected errors
            self.logger.error("Error occurred during the login process")
            print("❌ Error occurred during the login process:", e)
            print("🔄 Please try again later. If the issue persists, contact support.")
            print("=" * 50)
