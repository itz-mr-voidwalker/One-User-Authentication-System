import os
import logging

def Logger():
    try:
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('auth/auth.logs', mode='w')
            ]
        )
        return logging.getLogger(__name__)
    except Exception as e:
        print("Error Occured while initialising logging",e)
       