from auth.SecureLayer import SecureLayer
from auth.SendEmail import EmailVerification
from auth.logging import Logger
import random
import time
import getpass


class ForgotPassword:
    """
    Class to handle the forgotten password functionality, which includes
    email verification and the option to change the password.
    """
    
    def __init__(self):
        """
        Initializes the ForgotPassword class by calling the necessary functions
        to verify the user's email and allow them to reset their password.
        """
        self.logger = Logger()
        self.logger.info("Entered Forgot Password")
        
        while True:
            print("=" * 50)
            print("🔑 Forgot Password")
            self.enc = SecureLayer()
            self.user_data = self.enc.decrypt()
            
            # Verify the user's email before allowing password change
            email_verified = self.verify_email(self.user_data[1])
            
            if email_verified:
                self.logger.info("Email Verification Success")
                if self.change_password():
                    self.logger.info("Password Change Success")
                    print("✅ Password Changed Successfully!")
                    from auth.login import Login
                    login = Login()
                    break
                else:
                    self.logger.error("Failed to Change Password")
                    print("❌ Failed to change password. Please try again later.")
                    return                
            else:
                self.logger.error("Email Verification Failed")
                print("❌ Email verification failed. Please try again.")
    
    def change_password(self) -> bool:
        """
        Allows the user to enter a new password and attempts to change it.

        Returns:
            bool: True if the password was successfully changed, False otherwise.
        """
        print("\n\n")
        password = getpass.getpass("🔑 Enter new Password: ").strip()
        
        if not password:
            print("⚠️ Password input can't be empty. Please enter a valid password.")
            return False
        
        if len(password) < 8:
            print("⚠️ Password should be at least 8 characters long. Please try again.")
            return False
        
        changed = self.enc.encrypt(self.user_data[0], self.user_data[1], password)
        
        if changed:
            print("✅ Password changed successfully!")
            return True
        else:
            print("❌ Failed to change password. Please try again.")
            return False
        
    def verify_email(self, email: str) -> bool:
        """
        Sends a verification code to the user's email and prompts them to enter the
        received code for email verification.

        Args:
            email (str): The email address to send the verification code to.

        Returns:
            bool: True if the email is verified successfully, False otherwise.
        """
        try:
            self.code = random.randint(10000, 99999)  # Generate a 5-digit code
            created_at = int(time.time())  # Store timestamp of code generation

            # Send the verification email
            email_mgr = EmailVerification()
            email_mgr.send_email(
                subject='Email Verification',
                code=self.code,
                to_email=email
            )

            # Ask the user to input the verification code
            user_inp = input("🔢 Enter the code sent to your email: ").strip()

            try:
                user_inp = int(user_inp)
                current_time = int(time.time())

                # Check if the code has expired (10-minute window)
                if current_time - created_at > 600:
                    print("⏳ Code expired! Please request a new one.")
                    return False

                # Verify if the entered code matches the generated code
                if user_inp == self.code:
                    print("✅ Email verified successfully!")
                    return True
                else:
                    print("❌ Incorrect code. Please try again.")
                    return False

            except ValueError:
                print("❗ Invalid input! Please enter digits only.")
                return False
            
        except Exception as e:
            print(f"❌ Error occurred during email verification: {e}")
            print("Please try again later.")
            return False
