import tkinter as tk
from tkinter import messagebox
from auth.config import is_session_active, destroy_session

class App:
    def __init__(self,root):
        self.root = root
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def on_closing(self):
        if messagebox.askokcancel("Quit", "Do you really want to exit?"):
            destroy_session()
            print("Session Destroyed")
            self.root.destroy()
        else:
            return
    
    
    #Your App Code Goes Here

def app():
    if is_session_active():
        print("Session Active")
        root = tk.Tk()
        
        obj = App(root)
        root.mainloop()
    else:
        print("Pls Login")